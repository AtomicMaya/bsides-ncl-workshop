clear
sudo docker-compose down