clear
docker-compose down