<!-- put the css styling in the tags here, this is just so its hidden, you may design it in the css file for syntax highlighting and indentation -->
<style>
    .form {
        justify-content: center;
        margin-top: 30%;
    }

    .title {
        margin-top: 15%;
        font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
        text-align: center;
        text-decoration: dashed;
        text-transform: uppercase;
    }
</style>