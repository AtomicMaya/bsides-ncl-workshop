clear
docker-compose -f docker-compose.yaml up -d