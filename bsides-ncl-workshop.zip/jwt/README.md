# info

a JWT web challenge designed / conceieved by s4t4n with inspiration(see s4t4n for more info) and it was brought to life by Night(Kai) talk to them for further info.
