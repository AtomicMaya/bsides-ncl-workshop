# SQL Injection

## general info about the repository

you'll notice there is a raw SQL file titled `raw.sql` this is the dumped data showing what I have done and what the database consists of. Its roughly 6 users with their unique ID along with their name and "recovery code", said recovery code will contain the flag. unencrypted since this is more of a beginner challenge and ive already provided challenged with encoded flags.

## the flag

the flag is modified from the original idea of what a flag should be mainly since telling people about their cart on a simple login form made no sense. So now it says PHP needs PHDs

## for testers

this is a very simple program, so try and give it your best shot. I have no doubt all of you can do it, I would call this an intro to SQLi since some people may not have done it in a while or havent toucehd SQLi before

~Sable

(p.s.) please dont murder me i had to use SQLite to make it portable
